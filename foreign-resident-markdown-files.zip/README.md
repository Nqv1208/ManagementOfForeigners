# Hệ thống quản lý người nước ngoài

## 1. Giới thiệu

Dự án xây dựng hệ thống quản lý người nước ngoài, tập trung vào các nghiệp vụ cơ bản: xem thông tin công khai, đăng ký tài khoản, đăng nhập, khai báo tạm trú, quản lý lưu trú, tra cứu thông tin, phê duyệt khai báo, cảnh báo vi phạm và thống kê báo cáo.

Tài liệu này chỉ mô tả phạm vi chức năng đã xác định, không mở rộng sang các nghiệp vụ khác như bảo lãnh, visa, thẻ tạm trú hoặc quản trị nâng cao nếu chưa có yêu cầu riêng.

## 2. Tác nhân hệ thống

Hệ thống gồm 5 nhóm tác nhân chính:

| Tác nhân | Vai trò trong hệ thống |
|---|---|
| Khách vãng lai | Xem thông tin công khai và đăng ký tài khoản |
| Người nước ngoài | Khai báo tạm trú, cập nhật và tra cứu thông tin cá nhân |
| Chủ cơ sở lưu trú | Khai báo, cập nhật và quản lý thông tin lưu trú của người nước ngoài |
| Cán bộ quản lý xuất nhập cảnh | Tra cứu, thống kê, lập báo cáo và gửi cảnh báo vi phạm |
| Công an Phường/Xã | Phê duyệt khai báo, cảnh báo, báo cáo vi phạm và thống kê theo địa bàn |

## 3. Chức năng hệ thống

### 3.1. Khách vãng lai

- Xem các thông tin công khai: quy trình, hướng dẫn, văn bản pháp luật.
- Đăng ký tài khoản.

### 3.2. Người nước ngoài

- Đăng nhập.
- Khai báo tạm trú.
- Cập nhật nơi cư trú.
- Tra cứu thông tin cá nhân.
- Cập nhật thông tin cá nhân.

### 3.3. Chủ cơ sở lưu trú

- Đăng nhập.
- Khai báo lưu trú cho người nước ngoài.
- Cập nhật trạng thái lưu trú của người nước ngoài.
- Xem danh sách người nước ngoài đang lưu trú.
- Xem lịch sử khai báo lưu trú.
- Cập nhật thông tin cơ sở lưu trú.

### 3.4. Cán bộ quản lý xuất nhập cảnh

- Đăng nhập.
- Tra cứu thông tin người nước ngoài.
- Thống kê và lập báo cáo.
- Gửi cảnh báo về vi phạm của người nước ngoài.

### 3.5. Công an Phường/Xã

- Đăng nhập.
- Phê duyệt khai báo tạm trú trong Phường/Xã phụ trách.
- Cảnh báo vi phạm của người nước ngoài.
- Báo cáo vi phạm lên Cán bộ quản lý xuất nhập cảnh.
- Tra cứu người nước ngoài trên địa bàn phụ trách.
- Thống kê, báo cáo.

## 4. Module đề xuất

```text
src/
├── public-info/              # Thông tin công khai
├── auth/                     # Đăng ký, đăng nhập
├── foreigners/               # Người nước ngoài
├── residence-declarations/   # Khai báo tạm trú/lưu trú
├── accommodation-facilities/ # Cơ sở lưu trú
├── immigration-officers/     # Nghiệp vụ cán bộ xuất nhập cảnh
├── ward-police/              # Nghiệp vụ Công an Phường/Xã
├── violations/               # Cảnh báo và báo cáo vi phạm
├── reports/                  # Thống kê, báo cáo
└── shared/                   # Thành phần dùng chung
```

## 5. Dữ liệu chính

| Nhóm dữ liệu | Mô tả |
|---|---|
| Tài khoản | Lưu thông tin đăng nhập và vai trò người dùng |
| Người nước ngoài | Lưu thông tin cá nhân và thông tin cư trú |
| Cơ sở lưu trú | Lưu thông tin khách sạn, nhà trọ hoặc nơi lưu trú |
| Hồ sơ khai báo tạm trú | Lưu thông tin khai báo tạm trú của người nước ngoài |
| Lịch sử lưu trú | Lưu quá trình lưu trú, trạng thái đang ở/đã rời/quá hạn |
| Cảnh báo vi phạm | Lưu cảnh báo về vi phạm của người nước ngoài |
| Báo cáo vi phạm | Lưu báo cáo vi phạm gửi lên cán bộ quản lý xuất nhập cảnh |
| Báo cáo thống kê | Tổng hợp số liệu phục vụ quản lý |

## 6. Quy trình nghiệp vụ chính

### 6.1. Đăng ký và đăng nhập

```text
Khách vãng lai -> Đăng ký tài khoản -> Đăng nhập -> Sử dụng chức năng theo vai trò
```

### 6.2. Khai báo tạm trú của người nước ngoài

```text
Người nước ngoài -> Khai báo tạm trú -> Công an Phường/Xã phê duyệt -> Cập nhật trạng thái hồ sơ
```

### 6.3. Khai báo lưu trú bởi chủ cơ sở lưu trú

```text
Chủ cơ sở lưu trú -> Khai báo lưu trú -> Cập nhật trạng thái lưu trú -> Theo dõi danh sách/lịch sử lưu trú
```

### 6.4. Cảnh báo và báo cáo vi phạm

```text
Phát hiện vi phạm -> Tạo cảnh báo/báo cáo -> Cán bộ quản lý xuất nhập cảnh tiếp nhận -> Theo dõi xử lý
```

### 6.5. Thống kê và lập báo cáo

```text
Cán bộ/Công an Phường/Xã -> Lọc dữ liệu -> Thống kê -> Xuất báo cáo
```

## 7. Nguyên tắc bảo mật

- Chỉ người dùng đã đăng nhập mới được truy cập chức năng nội bộ.
- Mỗi vai trò chỉ được sử dụng đúng chức năng được phân quyền.
- Người nước ngoài chỉ được xem và cập nhật thông tin cá nhân của chính mình.
- Chủ cơ sở lưu trú chỉ được quản lý thông tin thuộc cơ sở của mình.
- Công an Phường/Xã chỉ xử lý dữ liệu trong địa bàn phụ trách.
- Không lưu mật khẩu dạng văn bản thường.
- Không hiển thị thông tin cá nhân nhạy cảm nếu người dùng không có quyền.
- Các thao tác quan trọng cần được ghi nhận để phục vụ kiểm tra sau này.

## 8. Trạng thái dữ liệu gợi ý

```text
TrangThaiTaiKhoan: ChoDuyet, HoatDong, BiKhoa
TrangThaiKhaiBao: ChoDuyet, DaDuyet, TuChoi
TrangThaiLuuTru: DangO, DaRoi, QuaHan
MucDoViPham: Nhe, TrungBinh, NghiemTrong
TrangThaiBaoCao: ChuaXuLy, DangXuLy, DaXuLy
```

## 9. Tiêu chí hoàn thành

- Có đầy đủ chức năng theo từng tác nhân.
- Có đăng ký, đăng nhập và phân quyền cơ bản.
- Có khai báo tạm trú và phê duyệt khai báo.
- Có quản lý lưu trú cho chủ cơ sở lưu trú.
- Có tra cứu thông tin người nước ngoài theo đúng phạm vi quyền.
- Có cảnh báo và báo cáo vi phạm.
- Có thống kê, báo cáo.
- Có kiểm tra dữ liệu đầu vào.
- Có xử lý lỗi rõ ràng.
